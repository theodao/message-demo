import React, { useState, useEffect } from "react";
import { Table, Input } from "antd";
import { connect } from "react-redux";
import { CompactPicker } from "react-color";
// import update from "immutability-helper";
import { DragSource, DropTarget } from "react-dnd";
import { MESSAGE } from "../../config/consts";
import Slider from "../../components/Slider";
import Modal from "../../components/Modal";
import helper from "../../helper";
import InputNumber from "../../components/InputNumber";
import {
  changeScale,
  changeGraphColor,
  changeChannels
} from "../../redux/actions";
import Flex from "../../components/styled/Flex";
import Channel from "./Channel";

const TableDisplay = ({
  data,
  refs,
  setting,
  changeScaleValue,
  changeGraphColor,
  changeChannels
}) => {
  let [visible, setVisible] = useState(false);
  // let [tableData, setTableData] = useState([]);
  let [modalData, setModalData] = useState({});
  let [min, setMin] = useState(null);
  let [max, setMax] = useState(null);
  let [minError, setMinError] = useState(null);
  let [maxError, setMaxError] = useState(null);
  let [colorError, setColorError] = useState(null);
  let [currentIndex, setCurrentIndex] = useState(null);
  let [color, setColor] = useState(null);

  const { channels, datasets } = setting;
  /**
   * Change the display value of the graph
   * @param {String[]} value Array of value [min, max] that you want to display
   * @param {Ref} ref Ref of your specific chart that you want to change
   */
  const handleInputChange = (value, ref) => {
    if (ref) {
      const {
        chartInstance: { scales }
      } = ref;

      scales["y-axis-0"].options.ticks.min = value[0];
      scales["y-axis-0"].options.ticks.max = value[1];
      ref.chartInstance.update();
    }
  };

  /**
   * Format input range
   * @param {Number} min Min value
   * @param {Number} max Max value
   */

  const handleClickDisplayName = i => {
    const {
      chartInstance: {
        data: { datasets }
      }
    } = refs.current[i];
    setVisible(true);
    setCurrentIndex(i);
    setModalData(data[i]);
    setMax(data[i].max_value);
    setMin(data[i].min_value);
    setColor(datasets[0].borderColor);
  };

  const handleChangeScale = (value, i) => {
    handleInputChange(value, refs.current[i]);
  };

  const handleMoveChannel = (dragIndex, hoverIndex) => {
    // const newChannel = update(data, {
    //   $splice: [
    //     [dragIndex, 1],
    //     [hoverIndex, 0, data[dragIndex]]
    //   ]
    // });
    // console.log(newChannel)
    // changeChannels(newChannel);
  };

  /**
   * Column format
   * @param {Ref[]} refs  Graph Ref List
   */
  const columns = refs => {
    return [
      {
        title: "Display Name",
        dataIndex: "display_name",
        width: "30%",
        render: (text, field, i) => (
          <div
            style={{ cursor: "pointer" }}
            onClick={() => {
              const {
                chartInstance: {
                  data: { datasets }
                }
              } = refs.current[i];
              setVisible(true);
              setCurrentIndex(i);
              setModalData(field);
              setMax(field.max_value);
              setMin(field.min_value);
              setColor(datasets[0].borderColor);
            }}
          >
            {text}
          </div>
        )
      },
      {
        title: "Scale",
        dataIndex: "data_label",
        width: "70%",
        align: "center",
        render: (item, field, index) => {
          return (
            <Slider
              vertical={true}
              style={{ height: "200px" }}
              min={field.min_value}
              step={0.01}
              max={field.max_value}
              defaultValue={[field.min_value, field.max_value]}
              // marks={formatMarks(field.min_value, field.max_value)}
              onChange={value => {
                handleInputChange(value, refs.current[index]);
              }}
            />
          );
        }
      }
    ];
  };

  /**
   * Format column
   */
  const settingColumns = () => {
    return [
      {
        title: "Message Label",
        dataIndex: "msg_label",
        width: "100px"
      },
      {
        title: "Data Label",
        dataIndex: "data_label",
        width: "100px"
      },
      {
        title: "Display Name",
        dataIndex: "display_name",
        width: "250px"
      },
      {
        title: "Min scale value",
        dataIndex: "min_value",
        width: "200px",
        render: (text, field) => {
          return (
            <InputNumber
              value={min}
              min={field.min_value}
              max={field.max_value}
              error={minError}
              onChange={e => {
                setMin(Number(e.target.value));
              }}
            />
          );
        }
      },
      {
        title: "Max scale value",
        dataIndex: "max_value",
        width: "200px",
        render: (text, field, i) => {
          return (
            <InputNumber
              value={max}
              min={field.min_value}
              error={maxError}
              max={field.max_value}
              onChange={e => {
                if (e.target.value <= min) {
                  setMaxError(MESSAGE.MAXSCALE_MINSCALE);
                } else {
                  setMaxError(null);
                }
                setMax(Number(e.target.value));
              }}
            />
          );
        }
      },
      {
        title: "Color",
        width: "200px",
        render: (text, field, i) => {
          return (
            <>
              <CompactPicker
                color={color}
                onChange={color => {
                  let error = null;
                  console.log(datasets);
                  for (let i = 0; i < datasets.length; i++) {
                    if (datasets[i].borderColor === color.hex) {
                      error = true;
                    }
                  }
                  if (error) {
                    setColorError(MESSAGE.COLOR_DUPLICATED);
                  } else {
                    setColorError(null);
                    setColor(color.hex);
                  }
                }}
              />
              <label className="error">{colorError}</label>
            </>
          );
        }
      }
    ];
  };

  return (
    <>
      <Modal
        visible={visible}
        title={modalData.display_name}
        width={1140}
        okButtonProps={{
          disabled: !!maxError || !!minError || !!colorError
        }}
        onCancel={() => {
          setVisible(false);
          setMaxError(null);
          setMinError(null);
        }}
        onOk={() => {
          changeGraphColor({ color, currentIndex });
          changeScaleValue({ min, max, currentIndex });
          setVisible(false);
        }}
        content={
          <Table
            pagination={false}
            rowKey="id"
            bordered={true}
            dataSource={[modalData]}
            columns={settingColumns()}
          />
        }
      />
      {/* <Table
        dataSource={data}
        pagination={false}
        rowKey="id"
        key={channels}
        bordered={false}
        locale={{ emptyText: MESSAGE.NO_DATA }}
        columns={columns(refs)}
        // scroll={{ x: "500px", y: "70vh" }}
      /> */}
      <Flex
        flexDirection="row"
        justifyContent="space-between"
        style={{
          padding: "20px",
          backgroundColor: "#fafafa",
          borderBottom: "1px solid #e8e8e8"
        }}
      >
        <div
          style={{
            width: "40%",
            fontWeight: "500",
            lineHeight: "21px",
            fontSize: "14px",
            color: "rgba(0, 0, 0, 0.85)"
          }}
        >
          Display name
        </div>
        <div
          style={{
            width: "60%",
            textAlign: "center",
            fontWeight: "500",
            lineHeight: "21px",
            fontSize: "14px",
            color: "rgba(0, 0, 0, 0.85)"
          }}
        >
          Scale
        </div>
      </Flex>
      {data.map((item, index) => {
        return (
          <Channel
            item={item}
            handleClickDisplayName={handleClickDisplayName}
            handleChangeScale={handleChangeScale}
            index={index}
            moveChannel={handleMoveChannel}
          />
        );
      })}
    </>
  );
};

const mapStateToProps = ({ mode, setting }) => ({ mode, setting });

const mapDispatchToProps = dispatch => ({
  changeScaleValue: data => dispatch(changeScale(data)),
  changeGraphColor: data => dispatch(changeGraphColor(data)),
  changeChannels: data => dispatch(changeChannels(data))
});

export default connect(mapStateToProps, mapDispatchToProps)(TableDisplay);
