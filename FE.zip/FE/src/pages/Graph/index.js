import React, { useState, useEffect, forwardRef } from "react";
import * as zoom from "chartjs-plugin-zoom";
import Hammer from "hammerjs";
import randomColor from "randomcolor";
import { DndProvider } from "react-dnd";
import Backend from "react-dnd-html5-backend";
import { connect } from "react-redux";
import Helper from "../../helper";
import Flex from "../../components/styled/Flex";
import LineChart from "../../components/LineChart";
import api from "../../api";
import {
  changeSetting,
  changeGraphSetting,
  changeMinMaxSetting,
  changeChannels,
  changeDataset
} from "../../redux/actions";
import TableDisplay from "./tableDisplay";
import helper from "../../helper";
import Modal from "../../components/Modal";
import Button from "../../components/Button";

// const Padding = styled.div`
//   padding: 10px;
// `;

const _options = {
  scales: {
    xAxes: [
      {
        type: "time",
        time: {
          format: "ss",
          unit: "second",
          unitStepSize: 1,
          distribution: "series",
          displayFormats: {
            minute: "ss",
            hour: "ss",
            second: "ss",
            millisecond: "ss"
          },
          tooltipFormat: "ss.SSS"
        },
        ticks: {
          min: helper.setSecond(0),
          max: helper.setSecond(60)
        },
        gridLines: {
          display: false
        }
      }
    ],
    yAxes: [
      {
        ticks: {
          min: 0,
          max: 160
        }
      }
    ]
  },
  legend: {
    display: true,
    position: "bottom"
  },
  elements: {
    line: {
      tension: 0
    }
  }
};

const Graph = ({
  onClick,
  isOpen,
  graphRef,
  setting,
  changeSetting,
  changeChannels,
  changeMinMaxSetting,
  changeDataset
}) => {
  // let [data, setData] = useState([]);
  // let [channels, setChannels] = useState([]);
  let [loading, setLoading] = useState(false);
  let [minTime, setMinTime] = useState(null);
  let [maxTime, setMaxTime] = useState(null);
  let [modalVisible, setModalVisible] = useState(false);
  let [options, setOptions] = useState(_options);

  const { graphOptions, channels, datasets } = setting;

  useEffect(() => {
    setOptions(graphOptions);
  }, [setting]);

  useEffect(() => {
    api
      .getValueData()
      .then(response => {
        console.log(response);
        const {
          data: {
            display_data: { channel, max_time, min_time }
          }
        } = response;
        setMaxTime(max_time);
        setMinTime(min_time);
        changeChannels(channel);
        // Setting graph option after fetching data finished
        changeMinMaxSetting({
          min_time,
          max_time
        });
        setOptions({
          ..._options,
          scales: {
            ..._options.scales,
            xAxes: [
              {
                ..._options.scales.xAxes[0],
                ticks: {
                  ..._options.scales.xAxes[0].ticks,
                  min: helper.setSecond(min_time),
                  max: helper.setSecond(max_time)
                }
              }
            ]
          }
        });

        // Filling data into the graph
        let datasets = [];
        channel.map(({ data, data_label, min_value, max_value }) => {
          // const color = randomColor();
          datasets.push({
            label: data_label,
            fill: false,
            order: 10,
            // borderColor: color,
            // pointBackgroundColor: color,
            // pointBorderColor: color,
            // pointHoverBackgroundColor: "green",
            // pointHoverBorderColor: "green",
            showLine: true,
            minValue: min_value,
            maxValue: max_value,
            spanGaps: false,
            data: data.map(item => {
              return {
                x: Helper.setSecond(item.time),
                y: item.value
              };
            })
          });
        });
        // setData(datasets);
        changeDataset(datasets);
        changeSetting({
          minTime: min_time,
          maxTime: max_time
        });
      })
      .catch(err => {
        // Handle error here
      });
  }, []);

  /**
   * Handle changing display unit time option
   * @param {string} value sec-msec-usec
   */
  const handleChangeDisplayOption = value => {
    const _unit = value === "sec" ? "ss" : "ss.SSS";

    setOptions({
      ...options,
      scales: {
        ...options.scales,
        xAxes: [
          {
            ...options.scales.xAxes[0],
            time: {
              ...options.scales.xAxes[0].time,
              format: _unit,
              unit: "second",
              unitStepSize: 1,
              distribution: "series",
              displayFormats: {
                ...options.scales.xAxes[0].time.displayFormats,
                minute: _unit,
                hour: _unit,
                second: _unit,
                millisecond: _unit
              }
            }
          }
        ]
      }
    });
  };

  return (
    <Flex style={{ height: "100%" }}>
      <Flex
        flexDirection="row"
        justifyContent="center"
        style={{ height: "90%" }}
      >
        <div
          style={{
            width: "20%",
            overflowY: "scroll",
            borderRight: "1px solid #eaeaea"
            // paddingTop: "16px"
          }}
        >
          <DndProvider backend={Backend}>
            <TableDisplay data={channels} refs={graphRef} />
          </DndProvider>
        </div>
        <div
          style={{
            width: "80%",
            padding: "16px 0 0 16px",
            height: "100%",
            overflowY: "scroll",
            overflowX: "hidden"
          }}
        >
          {datasets.map((_data, i) => {
            console.log(_data);
            return (
              <LineChart
                isOpen={isOpen}
                data={{
                  datasets: [_data]
                }}
                graphRef={r => (graphRef.current[i] = r)}
                options={{
                  ...options,
                  scales: {
                    ...options.scales,
                    yAxes: [
                      {
                        ...options.scales.yAxes[0],
                        ticks: {
                          ...options.scales.yAxes[0].ticks,
                          min: _data.minValue,
                          max: _data.maxValue,
                          callback: value => helper.formatNumber(value)
                        }
                      }
                    ]
                  }
                }}
                minValue={_data.minValue}
                maxValue={_data.maxValue}
              />
            );
          })}
        </div>
      </Flex>
      <Flex
        style={{
          height: "10%",
          borderTop: "1px solid #eaeaea",
          padding: "0 16px"
        }}
        justifyContent="flex-end"
        alignItems="center"
        flexDirection="row"
      >
        <div>
          <select
            onChange={e => {
              handleChangeDisplayOption(e.target.value);
            }}
          >
            <option value="sec">sec</option>
            <option value="msec">msec</option>
            <option value="usec">usec</option>
          </select>
        </div>
        <Modal
          title={<b className="error">Error</b>}
          content={<div className="error">Bad Request</div>}
          visible={modalVisible}
          onOk={() => setModalVisible(false)}
          onCancel={() => setModalVisible(false)}
          footer={[
            <Button type="delete" onClick={() => setModalVisible(false)}>
              OK
            </Button>
          ]}
        />
      </Flex>
    </Flex>
  );
};
const mapStateToProps = ({ mode, setting }) => ({ mode, setting });

const mapDispatchToProps = dispatch => ({
  changeSetting: data => dispatch(changeSetting(data)),
  changeGraphSetting: data => dispatch(changeGraphSetting(data)),
  changeMinMaxSetting: data => dispatch(changeMinMaxSetting(data)),
  changeChannels: data => dispatch(changeChannels(data)),
  changeDataset: data => dispatch(changeDataset(data))
});

export default connect(mapStateToProps, mapDispatchToProps, null, {
  forwardRef: true
})(Graph);
