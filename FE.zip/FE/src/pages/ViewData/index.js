import React, { useEffect, useState, useRef } from "react";
import { Icon } from "antd";
import styled from "styled-components";
import cx from "classnames";
import { connect, useSelector } from "react-redux";
import Flex from "../../components/styled/Flex";
import styles from "./styles.module.scss";
import LineChart from "../../components/LineChart";
import Graph from "../Graph";
import { GRAPH_MODE } from "../../config/consts";
import NumberTable from "../NumberTable";
import Slider from "../../components/Slider";
import helper from "../../helper";

const Padding = styled.div`
  padding: 0;
`;

const ViewData = ({ onClick, isOpen, mode, setting }) => {
  const { marks = {} } = setting;
  let [marksValue, setMarksValue] = useState({});
  let [inputValue, setInputValue] = useState([]);
  let chartRef = useRef([]);
  const handleInputChange = value => {
    setInputValue(value);
    chartRef.current.map(item => {
      const {
        chartInstance: { scales }
      } = item;
      scales["x-axis-0"].options.ticks.min = helper.setSecond(value[0]);
      scales["x-axis-0"].options.ticks.max = helper.setSecond(value[1]);
      item.chartInstance.update();
    });
  };
  // let _setting = useSelector(state => state.setting);
  useEffect(() => {
    const { minTime, maxTime } = marks;
    const _marksValue = {};
    for (let i = minTime; i <= maxTime; i++) {
      _marksValue[i] = {
        label: helper.formatNumber(i),
        style: {
          // fontSize: "10px"
        }
      };
    }
    setMarksValue(_marksValue);
  }, [setting]);

  return (
    <Padding>
      <Flex className={cx(styles.container)}>
        <Flex flexDirection="column" style={{ height: "100%" }}>
          <Flex
            flexDirection="row"
            alignItems="flex-start"
            className={cx(styles.block1)}
          >
            <Flex
              flexDirection="row"
              alignItems="center"
              className={cx(styles.block1_left)}
            >
              <Icon
                type={isOpen ? "left" : "right"}
                onClick={() => {
                  onClick();
                }}
                style={{ padding: "0 5px 0 0" }}
              />
              <div>
                <b>SELECT CHANNEL</b>
              </div>
            </Flex>
            <div style={{ width: "80%", padding: "16px 16px 0 16px" }}>
              <Slider
                style={{ width: "100%" }}
                min={marks.minTime}
                max={marks.maxTime}
                marks={marksValue}
                onChange={handleInputChange}
              />
            </div>
          </Flex>
          <div
            style={{
              borderTop: "1px solid #eaeaea",
              height: "90%"
            }}
          >
            {true ? (
              true ? (
                <Graph isOpen={isOpen} graphRef={chartRef} />
              ) : (
                <NumberTable range={inputValue} />
              )
            ) : null}
          </div>
        </Flex>
      </Flex>
    </Padding>
  );
};

const mapStateToProps = ({ mode, setting }) => ({ mode, setting });

const mapDispatchToProps = dispatch => {};

export default connect(mapStateToProps, mapDispatchToProps, null, {
  forwardRef: true
})(ViewData);
