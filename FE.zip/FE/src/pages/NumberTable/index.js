import React, { useState, useEffect } from "react";
import { Table } from "antd";
import { connect } from "react-redux";
import api from "../../api";
import { changeSetting } from "../../redux/actions";
import Modal from "../../components/Modal";
import Button from "../../components/Button";

const NumberTable = ({ changeSetting, range }) => {
  let [tableData, setTableData] = useState([]);
  let [filteredData, setFilteredData] = useState([]);
  let [channelName, setChannelName] = useState([]);
  let [ modalVisible, setModalVisible  ] = useState(false);

  useEffect(() => {
    const filteredData = tableData.filter(
      item => item.time >= range[0] && item.time <= range[1]
    );
    setFilteredData(filteredData);
  }, [range]);

  useEffect(() => {
    api
      .getValueData()
      .then(response => {
        console.log(response);
        const {
          data: {
            display_data: { channel, max_time, min_time }
          }
        } = response;
        let _data = [];
        channel.map(_channel => {
          const { data } = _channel;
          data.map(item => {
            const indexOldElement = _data.findIndex(
              _item => _item.time === item.time
            );
            if (indexOldElement !== -1) {
              _data[indexOldElement] = {
                ..._data[indexOldElement],
                [_channel.data_label]: item.value
              };
            } else {
              _data.push({
                time: item.time,
                [_channel.data_label]: item.value
              });
            }
          });
        });
        const newData = _data.sort((a, b) => a.time - b.time);
        setChannelName(channel.map(c => c.data_label));
        setTableData(newData);
        setFilteredData(newData);
        // Setting graph option after fetching data finished
        changeSetting({
          minTime: min_time,
          maxTime: max_time
        });
      })
      .catch(err => {
        // Catch error
      });
  }, []);

  useEffect(() => {
    console.log(tableData);
  }, [tableData]);

  const columns = () => {
    return [
      {
        title: "Time (sec)",
        dataIndex: "time",
        width: 280,
        fixed: true
      },
      ...channelName.map(name => {
        return {
          title: name,
          dataIndex: name,
          render: text => (text ? text : <div className="customCell">NONE</div>)
        };
      })
    ];
  };

  return (
    <>
      <Table
        dataSource={filteredData}
        pagination={false}
        rowKey="id"
        bordered={true}
        columns={columns()}
        scroll={{ x: "75vw" }}
      />
      <Modal
        title={<b className="error">Error</b>}
        content={<div className="error">Bad Request</div>}
        visible={modalVisible}
        onOk={() => setModalVisible(false)}
        onCancel={() => setModalVisible(false)}
        footer={[
          <Button type="delete" onClick={() => setModalVisible(false)}>
            OK
          </Button>
        ]}
      />
    </>
  );
};

const mapStateToProps = state => ({ mode: state.mode });

const mapDispatchToProps = dispatch => ({
  changeSetting: data => dispatch(changeSetting(data))
});

export default connect(mapStateToProps, mapDispatchToProps)(NumberTable);
