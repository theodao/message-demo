import React, { Fragment, useState, useEffect, useRef } from "react";
import { Table } from "antd";
import styled from "styled-components";
import { connect } from "react-redux";
import cx from "classnames";
import columns from "./columns";
import Button from "../../components/Button";
import Flex from "../../components/styled/Flex";
import { MESSAGE, GRAPH_MODE, NUMBERIC_MODE } from "../../config/consts";
import Modal from "../../components/Modal";
import api from "../../api";
import { changeViewMode } from "../../redux/actions";

const Container = styled.div`
  padding: 10px;
`;

const SelectChannel = ({ displayGraph, displayNumbericTable }) => {
  let [selectedRows, setSelectedRows] = useState(0);
  let [file, setFile] = useState(null);
  let [modalVisible, setModalVisible] = useState(false);
  let [errorRecord, setErrorRecord] = useState(null);
  let [data, setData] = useState([]);
  let [loading, setLoading] = useState(false);
  let [error, setError] = useState(null);
  const filePicker = useRef(null);

  useEffect(() => {}, []);

  // Handle uploading file
  const handleUpload = () => {
    // Mock calling api - PacketDataAnalysis
    setLoading(true);
    api
      .packetDataAnalysis()
      .then(response => {
        setLoading(false);
        if (response.status === 415) {
          setError(MESSAGE.WRONG_FORMAT);
        }
        if (response.status === 413) {
          setError(
            `${file ||
              file.name} is larger than 100mb. Please choose a smaller file`
          );
        }
        if (response.status === 204) {
          setError(MESSAGE.NO_DATA);
        }
        if (response.status === 200) {
          if (response.data.errors) {
            setError(
              `There are ${response.data.errors} error record(s) in the packet data file.`
            );
          }
          const {
            data: { channel }
          } = response;
          setData(channel);
        }
      })
      .catch(err => {
        setLoading(false);
        /**
         * Modal will pop up based on the response status code
         *
         */
      });
  };

  // Handle choosing channel
  const rowSelection = {
    onChange: (selectedRowKeys, selectedRows) => {
      setSelectedRows(selectedRows);
    },
    getCheckboxProps: record => ({
      name: record.name
    })
  };
  return (
    <Container>
      <div className="mb-20">
        <Flex flexDirection="row" justifyContent="space-between">
          <label>Choose file</label>
          <div>
            <input
              type="file"
              accept=".pcap, .pcapng"
              onChange={e => {
                // Handle choose file
                try {
                  const fileType = ["pcap", "pcapng"];
                  const file = e.currentTarget.files[0];
                  const arr = file.name.split(".");
                  if (!fileType.includes(arr[arr.length - 1].toLowerCase())) {
                    setError(MESSAGE.WRONG_FORMAT);
                  } else if (file.size > 104857600) {
                    setError(
                      `${file.name} is larger than 100mb. Please choose a smaller file`
                    );
                  } else {
                    setFile(file);
                    setError(null);
                  }
                } catch (error) {
                  setError(MESSAGE.EMPTY_FILE);
                }
              }}
              ref={filePicker}
            />
            <div className={cx("error", "mt-5")}>{error}</div>
          </div>

          <Button
            type="primary"
            onClick={handleUpload}
            disabled={!file || error}
          >
            Upload
          </Button>
        </Flex>
      </div>
      <Table
        className="table-select-channel"
        rowSelection={rowSelection}
        columns={columns({})}
        loading={loading}
        pagination={false}
        rowKey="id"
        locale={{ emptyText: MESSAGE.NO_DATA }}
        bordered={false}
        scroll={{ x: "25vw", y: "70vh" }}
        size="middle"
        dataSource={data}
      />
      <div style={{ padding: "10px" }}></div>
      <Flex flexDirection="row" justifyContent="space-between">
        <Button>{selectedRows.length} Selected channel(s)</Button>
        <Button
          type="primary"
          onClick={displayGraph}
          disabled={data.length === 0 || selectedRows.length > 10}
        >
          Graph
        </Button>
        <Button
          type="primary"
          onClick={displayNumbericTable}
          disabled={data.length === 0 || selectedRows.length > 50}
        >
          Numeric Table
        </Button>
      </Flex>
      <div className="mt-20">
        <div>Graph: Please choose max 10 channels</div>
        <div>Numeric Table: Please choose max 50 channels</div>
      </div>
      <Modal
        title={<b className="error">Error</b>}
        content={<div className="error">Bad Request</div>}
        visible={modalVisible}
        onOk={() => setModalVisible(false)}
        onCancel={() => setModalVisible(false)}
        footer={[
          <Button type="delete" onClick={() => setModalVisible(false)}>
            OK
          </Button>
        ]}
      />
    </Container>
  );
};

const mapStateToProps = state => ({ mode: state.mode });

const mapDispatchToProps = dispatch => ({
  displayGraph: () => dispatch(changeViewMode(GRAPH_MODE)),
  displayNumbericTable: () => dispatch(changeViewMode(NUMBERIC_MODE))
});

export default connect(mapStateToProps, mapDispatchToProps)(SelectChannel);
