import React, { useState } from "react";
import { Button, Icon } from "antd";
import SearchBar from "../../components/SearchBar";
import Flex from "../../components/styled/Flex";

// Custom search bar for each column in the table
const getColumnSearchProps = dataIndex => {
  // eslint-disable-next-line react-hooks/rules-of-hooks
  let [searchValue, setSearchValue] = useState("");
  // eslint-disable-next-line react-hooks/rules-of-hooks
  let [searchColumn, setSearchColumn] = useState("");

  return {
    filterDropdown: ({
      setSelectedKeys,
      selectedKeys,
      confirm,
      clearFilters
    }) => {
      return (
        <div style={{ padding: 8 }}>
          <SearchBar
            style={{ width: "150px", display: "block" }}
            setSelectedKeys={setSelectedKeys}
            setSearchValue={setSearchValue}
            setSearchColumn={setSearchColumn}
            selectedKeys={selectedKeys}
            confirm={confirm}
            dataIndex={dataIndex}
          />
          <Flex
            flexDirection="row"
            justifyContent="flex-end"
            style={{ marginTop: "8px" }}
          >
            <Button
              type="danger"
              onClick={() => {
                clearFilters();
                setSearchValue("");
                setSearchColumn("");
              }}
            >
              Clear
            </Button>
          </Flex>
        </div>
      );
    },
    filterIcon: filtered => (
      <Icon type="search" style={{ color: filtered ? "#1890ff" : undefined }} />
    ),
    onFilter: (value, record, field) =>
      record[dataIndex]
        .toString()
        .toLowerCase()
        .includes(value.toLowerCase()),
    render: text => text
  };
};

export default ({}) => [
  {
    title: "Message Label",
    dataIndex: "msg_label",
    ...getColumnSearchProps("msg_label")
  },
  {
    title: "Data Label",
    dataIndex: "data_label",
    ...getColumnSearchProps("data_label")
  },
  {
    title: "Display Name",
    dataIndex: "display_name",
    ...getColumnSearchProps("display_name")
  },
  {
    title: "Unit",
    dataIndex: "unit",
    ...getColumnSearchProps("unit")
  }
];
