import numeral from "numeral";

export default {
  /**
   * Format number to Second/Millisecond
   * @param {number} value - the value that you want to format
   */
  setSecond: value => {
    const data = String(value).split(".");
    return new Date("01/01/1996").setSeconds(data[0], data[1] || 0);
  },
  /**
   * Format number to 0.000
   * @param {string} value - the number that you want to format 
   */
  formatNumber: value => {
    return numeral(value).format("0.000")
  }
};
