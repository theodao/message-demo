import { createStore, applyMiddleware, combineReducers } from "redux";
import { createLogger } from "redux-logger";
import { persistStore, persistReducer, createTransform } from "redux-persist";
import storage from "redux-persist/lib/storage";
import { composeWithDevTools } from "redux-devtools-extension/developmentOnly";
import Flatted from "flatted";
import reducer from "../reducers";

// const transformCircular = createTransform(
//   (inboundState, key) => Flatted.stringify(inboundState),
//   (outboundState, key) => Flatted.parse(outboundState)
// );

const persistConfig = {
  key: "root",
  storage,
  // transforms: [transformCircular],
  whitelist: ["setting"],
};

// Middleware for redux
const getMiddleware = () => {
  return applyMiddleware(createLogger());
};

const persistedReducer = persistReducer(persistConfig, reducer)

// Config store
export default function configureStore() {
  const store = createStore(persistedReducer, composeWithDevTools(getMiddleware()));
  let persistor = persistStore(store);

  return {
    store,
    persistor
  };
}
