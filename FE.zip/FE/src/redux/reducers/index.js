import { combineReducers } from "redux";
import viewReducer from "./viewReducer";
import settingReducer from "./settingReducer";

// Root reducer
export default combineReducers({
  mode: viewReducer,
  setting: settingReducer,
})