import { ACTION } from "../../config/actionTypes";

// Reducer for view mode
export default (state = null, action) => {
  switch (action.type) {
    case ACTION.CHANGE_VIEWMODE:
      return action.payload;

    default:
      return state;
  }
};
