import randomColor from "randomcolor";
import { ACTION } from "../../config/actionTypes";
import helper from "../../helper";

// Reducer for zooming setting
export default (
  state = {
    marks: {},
    graphConfig: [],
    channels: [],
    datasets: [],
    graphOptions: {
      scales: {
        xAxes: [
          {
            type: "time",
            time: {
              format: "ss",
              unit: "second",
              unitStepSize: 1,
              distribution: "series",
              displayFormats: {
                minute: "ss",
                hour: "ss",
                second: "ss",
                millisecond: "ss"
              },
              tooltipFormat: "ss.SS"
            },
            ticks: {
              min: helper.setSecond(0),
              max: helper.setSecond(60)
            },
            gridLines: {
              display: false
            }
          }
        ],
        yAxes: [
          {
            ticks: {
              min: 0,
              max: 160
            }
          }
        ]
      },
      legend: {
        display: true,
        position: "bottom"
      }
    }
  },
  action
) => {
  switch (action.type) {
    case ACTION.CHANGE_SETTING:
      return {
        ...state,
        marks: action.payload
      };

    case ACTION.CHANGE_GRAPHSETTING:
      return {
        ...state,
        graphConfig: action.payload
      };
    case ACTION.CHANGE_MINMAX:
      return {
        ...state,
        graphOptions: {
          ...state.graphOptions,
          scales: {
            ...state.graphOptions.scales,
            xAxes: [
              {
                ...state.graphOptions.scales.xAxes[0],
                ticks: {
                  ...state.graphOptions.scales.xAxes[0].ticks,
                  min: helper.setSecond(action.payload.min_time),
                  max: helper.setSecond(action.payload.max_time)
                }
              }
            ]
          }
        }
      };
    case ACTION.CHANGE_SCALE:
      return {
        ...state,
        channels: Object.assign([...state.channels], {
          [action.payload.currentIndex]: {
            ...state.channels[action.payload.currentIndex],
            min_value: action.payload.min,
            max_value: action.payload.max
          }
        })
      };
    case ACTION.CHANGE_DATASETS:
      return {
        ...state,
        datasets: action.payload.map((item, index) => {
          console.log(item, "From reducer");
          const color = randomColor();
          // state.datasets[index].pointBorderColor;
          return {
            ...item,
            borderColor:
              state.datasets.length !== 0
                ? state.datasets[index].pointBorderColor
                : color,
            pointBackgroundColor:
              state.datasets.length !== 0
                ? state.datasets[index].pointBackgroundColor
                : color,
            pointBorderColor:
              state.datasets.length !== 0
                ? state.datasets[index].pointBackgroundColor
                : color
          };
        })
      };
    case ACTION.CHANGE_GRAPHCOLOR:
      return {
        ...state,
        datasets: Object.assign([...state.datasets], {
          [action.payload.currentIndex]: {
            ...state.datasets[action.payload.currentIndex],
            borderColor: action.payload.color,
            pointBorderColor: action.payload.color,
            pointBackgroundColor: action.payload.color
          }
        })
      };
    case ACTION.CHANGE_CHANNELS:
      return {
        ...state,
        channels:
          state.channels.length === 0
            ? action.payload
            : state.channels.map(item => ({ ...item }))
      };
    default:
      return state;
  }
};
