import { ACTION } from "../../config/actionTypes"

export const changeViewMode = (data) => {
  return {
    type: ACTION.CHANGE_VIEWMODE,
    payload: data
  }
}

export const changeSetting = (data) => {
  return {
    type: ACTION.CHANGE_SETTING,
    payload: data
  }
}

export const changeGraphSetting = (data) => {
  return {
    type: ACTION.CHANGE_GRAPHSETTING,
    payload: data
  }
}

export const changeMinMaxSetting = (data) => {
  return {
    type: ACTION.CHANGE_MINMAX,
    payload: data
  }
}

export const changeChannels = (data) => {
  return {
    type: ACTION.CHANGE_CHANNELS,
    payload: data
  }
}

export const changeScale = (data) => {
  return {
    type: ACTION.CHANGE_SCALE,
    payload: data
  }
}

export const changeDataset = (data) => {
  return {
    type: ACTION.CHANGE_DATASETS,
    payload: data
  }
}

export const changeGraphColor = (data) => {
  return {
    type: ACTION.CHANGE_GRAPHCOLOR,
    payload: data
  }
}