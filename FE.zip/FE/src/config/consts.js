// Error message
export const MESSAGE = {
  WRONG_FORMAT: "Wrong format! Please choose pcap/pcapng file.",
  EMPTY_FILE: "Empty file! Please choose other file.",
  NUMBERIC_MAXIMUM_CHANNEL: "Please do not select more than 10 channels",
  GRAPH_MAXIMUM_CHANNEL: "Please do not select more than 50 channels",
  SYSTEM_ERROR: "System Error",
  RESULT_NOT_FOUND: "Result not found.",
  BAD_REQUEST: "Bad Request",
  NO_DATA: "There is no data available",
  MAXSCALE_MINSCALE:
    "Please input Max scale value  larger than Min scale value.",
  COLOR_DUPLICATED: "Duplicated color! Please choose another color."
};

// API endpoit name
export const API_ENDPOINT = process.env.REACT_APP_API_URL || "";

// Format for json form data
export const JSON_FORM_DATA_OPTIONS = {
  showLeafArrayIndexes: true,
  includeNullValues: false
};

export const GRAPH_MODE = "GRAPH";
export const NUMBERIC_MODE = "NUMBERIC";
