import uuid from "uuid";

// Mock data for api getvaluedata
export const GetValueData = {
         status: 200,
         message: "Success",
         data: {
           display_data: {
             min_time: 0.0,
             max_time: 20.0,
             channel: [
               {
                 msg_label: "ADX2 LAT",
                 data_label: "LAT",
                 display_name: "自車絶対位置（緯度）",
                 min_value: 12.003,
                 max_value: 123.98,
                 data: [
                   {
                     time: 0.0,
                     value: 12.43488
                   },
                   {
                     time: 3,
                     value: 14.000009
                   },
                   {
                     time: 13,
                     value: 123.98
                   },
                   {
                     time: 19,
                     value: 127.98
                   },
                   {
                     time: 25,
                     value: 130
                   },
                   {
                     time: 36,
                     value: 180
                   },
                   {
                     time: 49,
                     value: 220
                   }
                 ]
               },
               {
                 msg_label: "ADX2 LON",
                 data_label: "LON",
                 display_name: "自車絶対位置（経度）",
                 min_value: -10,
                 max_value: 90.1562,
                 data: [
                   {
                     time: 0.0,
                     value: -10
                   },
                   {
                     time: 6,
                     value: 10.00001
                   },
                   {
                     time: 12.534,
                     value: 40.00001
                   },
                   {
                     time: 15,
                     value: 90.1562
                   },
                   {
                     time: 20,
                     value: 49.1562
                   }
                 ]
               },
               {
                 msg_label: "ADX2 LON",
                 data_label: "LON",
                 display_name: "自車絶対位置（経度）",
                 min_value: -10,
                 max_value: 90.1562,
                 data: [
                   {
                     time: 0.0,
                     value: -10
                   },
                   {
                     time: 6,
                     value: 10.00001
                   },
                   {
                     time: 12.534,
                     value: 40.00001
                   },
                   {
                     time: 15,
                     value: 90.1562
                   },
                   {
                     time: 20,
                     value: 49.1562
                   }
                 ]
               }
             ]
           }
         }
       };

// Mock data for api packet data analysis
export const PacketDataAnalysisData = {
  status: 200,
  message: "Success",
  data: {
    errors: 2,
    channel: [
      {
        msg_label: "ADX2 LAT",
        data_label: "LAT",
        display_name: "自車絶対位置（緯度）",
        unit: "deg",
        id: uuid()
      },
      {
        msg_label: "ADX2 LON",
        data_label: "LON",
        display_name: "自車絶対位置（経度）",
        unit: "deg",
        id: uuid()
      },
      {
        msg_label: "ADX2 HGT",
        data_label: "HGT",
        display_name: "自車絶対高度（楕円体高）",
        unit: "m",
        id: uuid()
      },
      {
        msg_label: "ADX2 HGT",
        data_label: "HGTX",
        display_name: "自車絶対高度（楕円体高）",
        unit: "h",
        id: uuid()
      },
      {
        msg_label: "ADX2 HGT",
        data_label: "HGTY",
        display_name: "自車絶対高度（楕円体高）",
        unit: "s",
        id: uuid()
      },
      {
        msg_label: "ADX2 HGT",
        data_label: "HGTZ",
        display_name: "自車絶対高度（楕円体高）",
        unit: "u",
        id: uuid()
      },
      {
        msg_label: "ADX2 HGT",
        data_label: "HGTK",
        display_name: "自車絶対高度（楕円体高）",
        unit: "t",
        id: uuid()
      },      {
        msg_label: "ADX2 HGT",
        data_label: "HGTJ",
        display_name: "自車絶対高度（楕円体高）",
        unit: "p",
        id: uuid()
      },
      {
        msg_label: "ADX2 HGT",
        data_label: "HGV",
        display_name: "自車絶対高度（楕円体高）",
        unit: "T",
        id: uuid()
      },
      {
        msg_label: "ADX2 HGT",
        data_label: "HGT",
        display_name: "自車絶対高度（楕円体高）",
        unit: "m",
        id: uuid()
      },      {
        msg_label: "ADX2 HGT",
        data_label: "HGT",
        display_name: "自車絶対高度（楕円体高）",
        unit: "m",
        id: uuid()
      },
      {
        msg_label: "ADX2 HGT",
        data_label: "HGT",
        display_name: "自車絶対高度（楕円体高）",
        unit: "m",
        id: uuid()
      }
    ]
  }
};
