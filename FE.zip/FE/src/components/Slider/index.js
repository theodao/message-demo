import React from "react";
import Slider from "rc-slider";
import "rc-slider/assets/index.css";

/**
 * Component to display search bar
 * @component
 */
export default ({
  range = true,
  marks,
  min = 0,
  max = 100,
  step = 0.01,
  vertical = false,
  defaultValue = [0, 100],
  onChange = () => {},
  ...props
}) => {
  return (
    <Slider.Range
      range={range}
      marks={marks}
      min={min}
      step={step}
      include={true}
      max={max}
      allowCross={false}
      vertical={vertical}
      dotStyle={
        vertical
          ? {
              width: "10px",
              height: "1px",
              borderRadius: "0%",
              border: "1px solid #e9e9e9",
              bottom: -4,
              left: -3,
              margin: 0,
              zIndex: 0
            }
          : {
              width: "1px",
              borderRadius: "0%",
              border: "1px solid #e9e9e9",
              bottom: -4,
              margin: 0,
              zIndex: 0
            }
      }
      handleStyle={[
        {
          borderColor: "#eaeaea",
          borderRadius: "0%",
          height: 12,
          width: 8,
          marginLeft: -2,
          marginTop: -4,
          backgroundColor: "#eaeaea",
          zIndex: 999
        },
        {
          borderColor: "#eaeaea",
          borderRadius: "0%",
          height: 12,
          width: 8,
          marginLeft: -2,
          marginTop: -4,
          backgroundColor: "#eaeaea",
          zIndex: 999
        }
      ]}
      activeDotStyle={{
        backgroundColor: "red",
        fontSize: "10px"
      }}
      dots={false}
      defaultValue={defaultValue}
      onChange={value => onChange(value)}
      {...props}
    />
  );
};
