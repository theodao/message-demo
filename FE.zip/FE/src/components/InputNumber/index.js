import React from "react";
import NumberFormat from "react-number-format";
import numeral from "numeral";
import cx from "classnames";
import styled from "styled-components";
import styles from "./styles.module.scss";

const Wrapper = styled.div`
  position: relative;
  width: 100%;

  .errorAbs {
    position: absolute;
    max-width: 250px;
    color: red;
    background-color: #fff;
    border-radius: 5px;
    display: none;
    right: 0;
    top: calc(100% + 5px);
    padding: 5px 10px;
  }

  &:hover {
    .errorAbs {
      display: block;
    }
  }
`;

/**
 * Component for formating number 
 * @component
 */

export default ({
  min = 0,
  max = 100000000,
  placeholder,
  value = 0,
  decimalScale = 3,
  decimalSeparator = ".",
  error = "",
  onChange = () => {},
  ...props
}) => {
  /**
   * Allow number only
   * @method
   * @param {Event} e Event
   */
  const handleKeyPress = e => {
    const code = e.which ? e.which : e.keyCode;
    if (code > 31 && (code < 46 || code > 57)) {
      e.preventDefault();
    }
  };

  /**
   * Ensure that value cannot be larger than maximum amount
   * @param {Event} e Event
   */
  const _onChange = e => {
    let newValue = numeral(e.target.value).value();
    if (newValue > max) {
      newValue = max;
    }
    e.target.value = newValue;
    onChange(e);
  };

  return (
    <Wrapper>
      <NumberFormat
        className={cx("ant-input", { [styles.inputError]: error })}
        value={value}
        onKeyPress={handleKeyPress}
        autoCorrect="false"
        autoComplete="false"
        placeholder={placeholder}
        decimalScale={decimalScale}
        decimalSeparator={decimalSeparator}
        onChange={_onChange}
        {...props}
      />
      <label className="errorAbs">{error}</label>
    </Wrapper>
  );
};
