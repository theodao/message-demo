import React  from "react";
import { Input } from "antd";

const { Search } = Input;

/**
 * Component to display search bar
 * @component
 */
export default ({
  placeholder = "Search",
  onSearch,
  setSelectedKeys,
  selectedKeys,
  setSearchColumn,
  setSearchValue,
  dataIndex,
  confirm,
  ...props
}) => {
  /**
   * Handle search action
   * @method
   * @param {Array} selectedKeys  array of keys
   * @param {Function} confirm Confirm function
   * @param {Number} dataIndex index of data
   */
  const handleSearch = (selectedKeys, confirm, dataIndex) => {
    confirm();
    setSearchValue(selectedKeys[0]);
    setSearchColumn(dataIndex);
    console.log(selectedKeys);
  };

  return (
    <>
      <Search
        placeholder={placeholder}
        onSearch={() => {
          handleSearch(selectedKeys, confirm, dataIndex);
        }}
        onChange={e => {
          setSelectedKeys(e.target.value ? [e.target.value] : []);
        }}
        {...props}
      />
    </>
  );
};
