/*
 *  @2019 Goldbell Financial Services Pte Ltd.
 *
 */

import React from "react";
import { Button, Icon } from "antd";
import cx from "classnames";

import styles from "./Button.module.scss";

/**
 * Component to display button
 * @component
 */
export default ({
  type = "grayOutline",
  className,
  icon,
  children,
  size,
  ...props
}) => (
  <Button
    {...props}
    className={cx(styles[type], styles.Button, className)}
    size={size}
  >
    {icon && <Icon type={icon} />}
    {children}
  </Button>
);
