import React, { Fragment } from "react";
import { Line } from "react-chartjs-2";
import * as zoom from "chartjs-plugin-zoom";
import styled from "styled-components";

const Container = styled.div`
  width: 100%;
  margin: 0 auto;
  display: flex;
`;

/**
 * Component to display chart
 * @component
 */

export default ({
  data,
  options,
  isOpen,
  minValue,
  maxValue,
  graphRef,
  onElementsClick = () => {}
}) => {
  return (
    <Fragment>
      <Container>
        <Line
          onElementsClick={e => onElementsClick(e)}
          data={data}
          key={isOpen}
          width={null}
          height={null}
          ref={graphRef}
          options={{
            ...options,
            aspectRatio: isOpen ? 3.5 : 5,
            maintainAspectRatio: true
          }}
        />
      </Container>
    </Fragment>
  );
};
