import React from "react";
import { Modal } from "antd";

/**
 * Component to display chart
 * @component
 */
export default ({
  content = "Content for modal",
  title = "Pop up modal",
  visible = false,
  footer,
  okButtonProps = {},
  width,
  onOk = () => {},
  onCancel = () => {}
}) => {
  return (
    <Modal
      title={title}
      onOk={onOk}
      width={width}
      onCancel={onCancel}
      visible={visible}
      footer={footer}
      okButtonProps={okButtonProps}
    >
      {content}
    </Modal>
  );
};
