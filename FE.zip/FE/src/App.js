import React, { useState, useEffect, useRef } from "react";
import Sidebar from "react-sidebar";
import SelectChannel from "./pages/SelectChannel";
import ViewData from "./pages/ViewData";

function App() {
  let [isOpen, setOpen] = useState(true);

  const toggleSidebar = open => {
    setOpen(open);
  };

  return (
    <div className="App">
      <Sidebar
        sidebar={<SelectChannel />}
        open={isOpen}
        docked={isOpen}
        onSetOpen={toggleSidebar}
        styles={{ sidebar: { background: "white" } }}
      >
        <ViewData onClick={() => toggleSidebar(!isOpen)} isOpen={isOpen}/>
      </Sidebar>
    </div>
  );
}

export default App;
