import Api from "./api";
import { API_ENDPOINT as baseUri } from "../config/consts";
import { PacketDataAnalysisData, GetValueData } from "../config/mockData";

export default {
  /**
   * Packet data analysis
   * @returns Promise
   */
  packetDataAnalysis: () => {
    return Promise.resolve(PacketDataAnalysisData);
  },
  
  /**
   * Get value data
   * @returns Promise
   */
  getValueData: () => {
    return Promise.resolve(GetValueData)
  }
};
