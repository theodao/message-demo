import querystring from "query-string";
import { JSON_FORM_DATA_OPTIONS } from "../config/consts";
import json2formdata from "json-form-data";

export class HttpException extends Error {
  constructor({ message, status, statusText, url, ErrorCode, data } = {}) {
    super(message);
    this.status = status;
    this.statusText = statusText;
    this.url = url;
    this.ErrorCode = ErrorCode;
    this.data = data;
  }
}

export default class Api {
  /**
   * 
   * @param {object} obj Object setting
   * @param {string} obj.baseUri base url
   * @param {string} obj.token jwt token
   * @param {boolean} obj.useFormData use form data 
   */
  constructor({ baseUri, token, useFormData = false }) {
    this.baseUri = baseUri || "";
    this.credentials = token && token.length > 0 ? token : null;
    this.useFormData = useFormData;
    this.headersBuilder = newToken => {
      var token = newToken || this.credentials;
      const headers = {};
      if (!this.useFormData) {
        headers["Content-Type"] = "application/json";
      }
      if (token) {
        headers.Authorization = token;
      }
      return headers;
    };
  }
  /**
   * Call api method
   * @method
   * @param {object} obj - Object setting
   * @param {string} obj.method - name of the method
   * @param {string} obj.path - path of the method
   * @param {object} obj.data - data of the method
   * @returns Promise
   */
  callApi({ method, path, data, newToken = null }) {
    const newBody = this.useFormData
      ? json2formdata(data, JSON_FORM_DATA_OPTIONS)
      : JSON.stringify(data);
    const fetchOption = {
      method: method,
      mode: "cors",
      headers: this.headersBuilder(newToken),
      body: data !== null ? newBody : null
    };
    return fetch(this.baseUri + path, fetchOption).then(response => {
      if (response.ok) {
        return response.json();
      } else if (response.status === 500) {
        const _err = {
          message: "System Error",
          ErrorCode: response.status,
          status: response.status,
          statusText: `HttpException[${method}]`
        };
        throw new HttpException({ ..._err });
      } else if (response.status === 400) {
        const _err = {
          message: "Bad Request",
          ErrorCode: response.status,
          status: response.status,
          statusText: `HttpException[${method}]`
        };
        throw new HttpException({ ..._err });
      } else {
        return response.json().then(metaError => {
          throw new HttpException({
            message: metaError.message || metaError.result,
            ErrorCode: response.status,
            status: response.status,
            statusText: `HttpException[${method}]`
          });
        });
      }
    });
  }

  /**
   * Get method
   * @param {object} object setting
   * @param {string} object.path path of the method
   * @param {object} object.data data of the method
   * @return Promise
   */
  getData({ path, data = {} }) {
    const paramsString = querystring.stringify(data);

    const fullpath = path + (paramsString === "" ? "" : "?" + paramsString);
    return this.callApi({
      method: "GET",
      path: fullpath,
      data: null
    });
  }

  /**
   * Post method
   * @param {object} object setting
   * @param {string} object.path path of the method
   * @param {object} object.data data of the method
   * @return Promise
   */
  postData({ path, data }) {
    return this.callApi({
      method: "POST",
      path,
      data
    });
  }

  /**
   * Put method
   * @param {object} object setting
   * @param {string} object.path path of the method
   * @param {object} object.data data of the method
   * @return Promise
   */
  putData({ path, data }) {
    return this.callApi({
      method: "PUT",
      path,
      data
    });
  }

  /**
   * Delete method
   * @param {object} object setting
   * @param {string} object.path path of the method
   * @param {object} object.data data of the method
   * @return Promise
   */

  deleteData({ path, data }) {
    return this.callApi({
      method: "DELETE",
      path,
      data
    });
  }
}
